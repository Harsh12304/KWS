'use client'
import React from 'react';
import Navbar from '@/components/layouts/navbar/Navbar';
import AGM2023 from '@/components/media/agm2023/agm2023';
import Footer from '@/components/footer/footer';







function page() {
    return (
      <>
        <Navbar/>
        <AGM2023/>
        <Footer/>

   
       
      </>
    );
  }
  
  export default page;