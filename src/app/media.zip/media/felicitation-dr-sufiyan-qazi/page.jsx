'use client'
import React from 'react';
import Navbar from '@/components/layouts/navbar/Navbar';
import FelicitationPage from '@/components/media/felicitation-dr-sufiyan-qazi/felicitation-dr-sufiyan-qazi';
import Footer from '@/components/footer/footer';







function page() {
    return (
      <>
        <Navbar/>
        <FelicitationPage/>
        <Footer/>

   
       
      </>
    );
  }
  
  export default page;